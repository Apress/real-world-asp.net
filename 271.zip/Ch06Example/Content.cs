using System;

namespace Ch06Example
{
	public class Content
	{
        protected string headline;
        protected string story;

		public Content(string h, string s)
		{
            headline = h;
            story = s;
		}

        public string Headline
        {
            get
            {
                return headline;
            }
        }

        public string Story
        {
            get
            {
                return story;
            }
        }
	}
}
