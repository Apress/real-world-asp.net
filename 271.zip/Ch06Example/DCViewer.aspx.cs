using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace Ch06Example
{
    public class WebForm1 : System.Web.UI.Page
    {
        protected Content[] Stories = new Content[3];
        protected System.Web.UI.WebControls.TextBox tbUserName;
        protected System.Web.UI.WebControls.TextBox tbNumber;
        protected System.Web.UI.WebControls.DropDownList ddlStories;
        protected System.Web.UI.WebControls.RequiredFieldValidator rfvUserName;
        protected System.Web.UI.WebControls.RequiredFieldValidator rfvNumber;
        protected System.Web.UI.WebControls.RangeValidator rvNumber;
        protected System.Web.UI.WebControls.ValidationSummary ValidationSummary1;
        protected System.Web.UI.WebControls.Label lbStory;
        protected System.Web.UI.WebControls.Button bnGetStory;
    
        private void Page_Load(object sender, System.EventArgs e)
        {
            if (!IsPostBack)
            {
                for (int i = 0; i < Stories.Length; i++)
                {
                    ddlStories.Items.Add(new ListItem(Stories[i].Headline, i.ToString()));
                }
            }
            else
            {
                lbStory.Text = 
                    String.Format(
                        Stories[Convert.ToInt16(ddlStories.SelectedItem.Value)].Story,
                        tbUserName.Text, tbNumber.Text);
            }
        }

        #region Web Form Designer generated code
        override protected void OnInit(EventArgs e)
        {
            InitializeComponent();
            base.OnInit(e);

            Stories[0] = new Content("New Hall of Fame Member", 
                "{0} joined the hockey hall of fame due to {1} MVP trophies.");
            Stories[1] = new Content("Hacker Located", 
                "{0} has been arrested on {1} accounts of bad coding.");
            Stories[2] = new Content("Lottery Winner", 
                "{0} said all {1} million in lottery winnings is going to charity.");
        }
        
        private void InitializeComponent()
        {    
            this.Load += new System.EventHandler(this.Page_Load);

        }
        #endregion

    }
}
