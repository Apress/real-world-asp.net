using System;

namespace CMSNET.Common
{
	/// <summary>
	/// Summary description for StatusCodes.
	/// </summary>
	public class StatusCodes
	{
		public StatusCodes()
		{
			//
			// TODO: Add constructor logic here
			//
		}

        public static int Creating  = 0x00000001;
        public static int Submitted = 0x00000002;
    }
}
