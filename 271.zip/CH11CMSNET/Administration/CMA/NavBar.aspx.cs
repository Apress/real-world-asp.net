using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Xml;

namespace CMSNET.Administration.CMA
{
	/// <summary>
	/// Summary description for Menu.
	/// </summary>
	public class NavBar : System.Web.UI.Page
	{
        protected System.Web.UI.WebControls.Table tblMenu;
    
		private void Page_Load(object sender, System.EventArgs e)
		{
            XmlReader reader = new XmlTextReader(File.OpenRead(Server.MapPath("..\\..\\XMLFiles\\CMAMenu.xml")));

            XmlDocument doc = new XmlDocument();
            doc.Load(reader);
            reader.Close();

            string expand = Request.QueryString["Expand"];
            
            int ExpandWhich;
            if (expand == null)
                ExpandWhich = -1;
            else
                ExpandWhich = Convert.ToInt16(expand);

            TableCell   cell;
            HyperLink   link;

            XmlNodeList Menus = doc.GetElementsByTagName("Menu");

            for (int i = 0; i < Menus.Count; i++)
            {
                TableRow row = new TableRow();
                tblMenu.Rows.Add(row);
                
                if (ExpandWhich == i)
                {
                    cell = new TableCell();
                    cell.Width = Unit.Percentage(1.0);

                    System.Web.UI.WebControls.Image image = 
                        new System.Web.UI.WebControls.Image();
                    image.ImageUrl = "Images/minus.gif";
                    image.Width = Unit.Pixel(11);
                    image.Height = Unit.Pixel(11);
                    image.BorderWidth = Unit.Pixel(0);
                    cell.Controls.Add(image);

                    row.Cells.Add(cell);

                    link = new HyperLink();
                    link.Text = Menus[i].FirstChild.InnerText;
                    link.NavigateUrl = "NavBar.aspx?Expand=-1";

                    cell = new TableCell();
                    cell.Width = Unit.Percentage(99.0);
                    cell.Controls.Add(link);

                    row.Cells.Add(cell);

                    XmlNodeList MenuNodes = Menus[i].ChildNodes;

                    // start at 1 since 0 is the Menu Name
                    for (int j = 1; j < MenuNodes.Count; j++)
                    {
                        row = new TableRow();
                        tblMenu.Rows.Add(row);

                        cell = new TableCell();
                        cell.Width = Unit.Percentage(1.0);

                        image = new System.Web.UI.WebControls.Image();
                        image.ImageUrl = "Images/blank.gif";
                        image.Width = Unit.Pixel(11);
                        image.Height = Unit.Pixel(11);
                        image.BorderWidth = Unit.Pixel(0);
                        cell.Controls.Add(image);

                        row.Cells.Add(cell);

                        link = new HyperLink();
                        link.Text = MenuNodes[j].ChildNodes[0].InnerText;
                        link.NavigateUrl = MenuNodes[j].ChildNodes[1].InnerText;
                        link.Target = "main";

                        cell = new TableCell();
                        cell.Width = Unit.Percentage(99.0);
                        cell.Controls.Add(link);

                        row.Cells.Add(cell);
                    }
                }
                else
                {
                    cell = new TableCell();
                    cell.Width = Unit.Percentage(1.0);

                    System.Web.UI.WebControls.Image image = 
                        new System.Web.UI.WebControls.Image();
                    image.ImageUrl = "Images/plus.gif";
                    image.Width = Unit.Pixel(11);
                    image.Height = Unit.Pixel(11);
                    image.BorderWidth = Unit.Pixel(0);
                    cell.Controls.Add(image);

                    row.Cells.Add(cell);

                    link = new HyperLink();
                    link.Text = Menus[i].FirstChild.InnerText;
                    link.NavigateUrl = "NavBar.aspx?Expand=" + i;

                    cell = new TableCell();
                    cell.Width = Unit.Percentage(99.0);
                    cell.Controls.Add(link);

                    row.Cells.Add(cell);
                }
            }
        }

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
            this.Load += new System.EventHandler(this.Page_Load);

        }
		#endregion
	}
}
