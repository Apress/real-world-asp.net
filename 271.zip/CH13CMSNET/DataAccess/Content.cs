using System;
using System.Data;
using System.Data.SqlClient;
using System.Web.Security;

using CMSNET.Common;

namespace CMSNET.DataAccess
{
    /// <summary>
    /// Summary description for Content.
    /// </summary>
    public class Content
    {
        private SqlConnection m_Connection;

        public Content(SqlConnection Connection)
        {
            m_Connection = Connection;
        }

        public void Insert(string Headline, int Byline, string Teaser, string Body, 
            string Tagline)
        {
            Insert(NextContentID(), 1, Headline, Byline, Teaser, Body, Tagline, Byline);
        }

        public void Insert(int ContentID, int Version, string Headline, int Byline, 
            string Teaser, string Body, string Tagline, int UpdUserID)
        {
            // INSERT INTO Content (ContentID, Version, Headline, Byline, 
            //                      Teaser, Body, Tagline, Status, UpdateUserID, 
            //                      ModifiedDate, CreationDate) 
            // VALUES (@ContentID, @Version, @Headline, @Byline, @Teaser, @Body, 
            //         @Tagline, @Status, @UpdateUserID, @ModifiedDate, @CreationDate)

            SqlCommand Command = new SqlCommand("Content_Insert", m_Connection);
            Command.CommandType  = CommandType.StoredProcedure;
            
            Command.Parameters.Add(new SqlParameter("@ContentID",    SqlDbType.Int));
            Command.Parameters.Add(new SqlParameter("@Version",      SqlDbType.Int));
            Command.Parameters.Add(new SqlParameter("@Headline",     SqlDbType.Text));
            Command.Parameters.Add(new SqlParameter("@Byline",       SqlDbType.Int));
            Command.Parameters.Add(new SqlParameter("@Teaser",       SqlDbType.Text));
            Command.Parameters.Add(new SqlParameter("@Body",         SqlDbType.Text));
            Command.Parameters.Add(new SqlParameter("@Tagline",      SqlDbType.Text));
            Command.Parameters.Add(new SqlParameter("@Status",       SqlDbType.Int));
            Command.Parameters.Add(new SqlParameter("@UpdateUserID", SqlDbType.Int));
            Command.Parameters.Add(new SqlParameter("@ModifiedDate", SqlDbType.DateTime));
            Command.Parameters.Add(new SqlParameter("@CreationDate", SqlDbType.DateTime));

            Command.Parameters["@ContentID"].Value    = ContentID;
            Command.Parameters["@Version"].Value      = Version;
            Command.Parameters["@Headline"].Value     = Headline;
            Command.Parameters["@Byline"].Value       = Byline;
            Command.Parameters["@Teaser"].Value       = Teaser;
            Command.Parameters["@Body"].Value         = Body;
            Command.Parameters["@Tagline"].Value      = Tagline;
            Command.Parameters["@Status"].Value       = StatusCodes.Creating;
            Command.Parameters["@UpdateUserID"].Value = UpdUserID;
            Command.Parameters["@ModifiedDate"].Value = DateTime.Now;
            Command.Parameters["@CreationDate"].Value = DateTime.Now;
					
            try
            {
                m_Connection.Open();
                Command.ExecuteNonQuery();
            }
            finally
            {
                m_Connection.Close();
            }
        }

        public void Update(int ContentID, int Version, string Headline, int Byline, 
            string Teaser, string Body, string Tagline, int UpdUserID)
        {
            // UPDATE Content
            // SET 
            //        Headline     = @Headline,
            //        Byline       = @Byline,
            //        Teaser       = @Teaser,
            //        Body         = @Body,
            //        Tagline      = @Tagline,
            //        Status       = @Status,
            //        UpdateUserID = @UpdateUserID,
            //        ModifiedDate = @ModifiedDate
            // WHERE  ContentID = @ContentID
            //   AND  Version = @Version

            SqlCommand Command = new SqlCommand("Content_Update", m_Connection);
            Command.CommandType  = CommandType.StoredProcedure;
            
            Command.Parameters.Add(new SqlParameter("@ContentID",    SqlDbType.Int));
            Command.Parameters.Add(new SqlParameter("@Version",      SqlDbType.Int));
            Command.Parameters.Add(new SqlParameter("@Headline",     SqlDbType.Text));
            Command.Parameters.Add(new SqlParameter("@Byline",       SqlDbType.Int));
            Command.Parameters.Add(new SqlParameter("@Teaser",       SqlDbType.Text));
            Command.Parameters.Add(new SqlParameter("@Body",         SqlDbType.Text));
            Command.Parameters.Add(new SqlParameter("@Tagline",      SqlDbType.Text));
            Command.Parameters.Add(new SqlParameter("@Status",       SqlDbType.Int));
            Command.Parameters.Add(new SqlParameter("@UpdateUserID", SqlDbType.Int));
            Command.Parameters.Add(new SqlParameter("@ModifiedDate", SqlDbType.DateTime));

            Command.Parameters["@ContentID"].Value    = ContentID;
            Command.Parameters["@Version"].Value      = Version;
            Command.Parameters["@Headline"].Value     = Headline;
            Command.Parameters["@Byline"].Value       = Byline;
            Command.Parameters["@Teaser"].Value       = Teaser;
            Command.Parameters["@Body"].Value         = Body;
            Command.Parameters["@Tagline"].Value      = Tagline;
            Command.Parameters["@Status"].Value       = StatusCodes.Creating;
            Command.Parameters["@UpdateUserID"].Value = UpdUserID;
            Command.Parameters["@ModifiedDate"].Value = DateTime.Now;
					
            try
            {
                m_Connection.Open();
                Command.ExecuteNonQuery();
            }
            finally
            {
                m_Connection.Close();
            }
        }

        public void SetStatus(int ContentID, int Version, int Status)
        {
            // UPDATE Content
            // SET 
            //        Status       = @Status,
            //        ModifiedDate = @ModifiedDate
            // WHERE  ContentID = @ContentID
            //   AND  Version = @Version

            SqlCommand Command = new SqlCommand("Content_SetStatus", m_Connection);
            Command.CommandType  = CommandType.StoredProcedure;
            
            Command.Parameters.Add(new SqlParameter("@ContentID",    SqlDbType.Int));
            Command.Parameters.Add(new SqlParameter("@Version",      SqlDbType.Int));
            Command.Parameters.Add(new SqlParameter("@Status",       SqlDbType.Int));
            Command.Parameters.Add(new SqlParameter("@ModifiedDate", SqlDbType.DateTime));

            Command.Parameters["@ContentID"].Value    = ContentID;
            Command.Parameters["@Version"].Value      = Version;
            Command.Parameters["@Status"].Value       = Status;
            Command.Parameters["@ModifiedDate"].Value = DateTime.Now;
					
            try
            {
                m_Connection.Open();
                Command.ExecuteNonQuery();
            }
            finally
            {
                m_Connection.Close();
            }
        }

        public int NextContentID()
        {
            // SELECT DISTINCT ContentID 
            // FROM   Content
            // ORDER BY ContentID DESC

            SqlCommand Command = new SqlCommand("Content_NextContentID", m_Connection);
            Command.CommandType = CommandType.StoredProcedure;

            SqlDataAdapter DAdpt = new SqlDataAdapter(Command);

            DataSet ds = new DataSet();
            DAdpt.Fill(ds, "Content");

            if (ds.Tables["Content"].Rows.Count <= 0)
                return 1;

            return Convert.ToInt32(ds.Tables["Content"].Rows[0]["ContentID"]) + 1;
        }

        public DataTable GetHeadlines()
        {
            // Select   ContentID, Version, Headline, Status 
            // FROM     Content
            // ORDER BY ContentID ASC, Version DESC

            SqlCommand Command = new SqlCommand("Content_GetHeadlines", m_Connection);
            Command.CommandType = CommandType.StoredProcedure;

            SqlDataAdapter DAdpt = new SqlDataAdapter(Command);

            DataSet ds = new DataSet();
            DAdpt.Fill(ds, "Content");

            return ds.Tables["Content"];
        }

        public DataTable GetContentForID(int cid)
        {
            // SELECT * 
            // FROM Content 
            // WHERE ContentID=@cid
            // ORDER BY Version DESC

            SqlCommand Command = new SqlCommand("Content_GetContentForID", m_Connection);
            Command.CommandType = CommandType.StoredProcedure;
            Command.Parameters.Add(new SqlParameter("@cid", SqlDbType.Int));
            Command.Parameters["@cid"].Value = cid;

            SqlDataAdapter DAdpt = new SqlDataAdapter(Command);

            DataSet ds = new DataSet();
            DAdpt.Fill(ds, "Content");

            return ds.Tables["Content"];
        }

        public DataRow GetContentForIDVer(int cid, int ver)
        {
            // SELECT * 
            // FROM Content 
            // WHERE ContentID=@cid
            //   AND Version=@ver

            SqlCommand Command = new SqlCommand("Content_GetContentForIDVer", m_Connection);
            Command.CommandType = CommandType.StoredProcedure;
            Command.Parameters.Add(new SqlParameter("@cid", SqlDbType.Int));
            Command.Parameters.Add(new SqlParameter("@ver", SqlDbType.Int));
            Command.Parameters["@cid"].Value = cid;
            Command.Parameters["@ver"].Value = ver;

            SqlDataAdapter DAdpt = new SqlDataAdapter(Command);

            DataSet ds = new DataSet();
            DAdpt.Fill(ds, "Content");

            if (ds.Tables["Content"].Rows.Count > 0)
                return ds.Tables["Content"].Rows[0];
            else
                return null;
        }

        public void Remove(int cid, int ver)
        {
            // DELETE FROM Content 
            // WHERE ContentID=@cid
            //   AND Version=@ver

            SqlCommand Command = new SqlCommand("Content_Remove", m_Connection);
            Command.CommandType = CommandType.StoredProcedure;

            Command.Parameters.Add(new SqlParameter("@cid", SqlDbType.Int));
            Command.Parameters.Add(new SqlParameter("@ver", SqlDbType.Int));
            Command.Parameters["@cid"].Value = cid;
            Command.Parameters["@ver"].Value = ver;

            try
            {
                m_Connection.Open();
                Command.ExecuteNonQuery();
            }
            finally
            {
                m_Connection.Close();
            }
        }
    }
}
