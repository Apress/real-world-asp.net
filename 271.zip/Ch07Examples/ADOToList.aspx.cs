using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace Ch07Examples
{
	public class ADOToList : System.Web.UI.Page
	{
        protected System.Web.UI.WebControls.ListBox ListBox1;
    
        private void Page_Load(object sender, System.EventArgs e)
        {
            if (!IsPostBack)
            {
                string ConnectStr = "server=localhost;uid=sa;pwd=;database=DCV_DB";
                string Cmd = "SELECT * FROM Authors ORDER BY LastName";
 
                SqlDataAdapter DAdpt = new SqlDataAdapter(Cmd, ConnectStr);
            
                DataSet ds = new DataSet();
                DAdpt.Fill(ds, "Authors");
            
                DataTable dt = ds.Tables["Authors"];

                foreach (DataRow dr in dt.Rows)
                {
                    ListBox1.Items.Add(dr["LastName"] + ", " + 
                        dr["FirstName"] + ": " + 
                        dr["Email"]);
                }
            }
        }
		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			InitializeComponent();
			base.OnInit(e);
		}
		
		private void InitializeComponent()
		{    
            this.Load += new System.EventHandler(this.Page_Load);

        }
        #endregion
	}
}
