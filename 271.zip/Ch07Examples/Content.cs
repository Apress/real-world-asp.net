using System;
using System.Data;
using System.Data.SqlClient;

namespace Ch07Examples
{
	public class Content
	{
        private SqlConnection m_Connection;
        private SqlCommand    m_InsertCommand;
        
        public Content(SqlConnection Connection)
		{
            m_Connection = Connection;		
        }

        public void Insert(int AuthorID, string Headline, string Story)
        {
            SqlParameterCollection Params;

            if ( m_InsertCommand == null )
            {
                // Only create Insert command the first time
                m_InsertCommand = new SqlCommand("InsertContent", 
                    m_Connection);
                m_InsertCommand.CommandType  = CommandType.StoredProcedure;
                Params = m_InsertCommand.Parameters;

                Params.Add(new SqlParameter("@AuthorID", SqlDbType.Int));
                Params.Add(new SqlParameter("@Headline", SqlDbType.Char, 64));
                Params.Add(new SqlParameter("@Story",    SqlDbType.Text));
            }
            Params = m_InsertCommand.Parameters;

            Params["@AuthorID"].Value = AuthorID;
            Params["@Headline"].Value = Headline;
            Params["@Story"].Value    = Story;

            try
            {
                m_Connection.Open();
                m_InsertCommand.ExecuteNonQuery();
            }
            finally
            {
                m_Connection.Close();
            }
        }
    }
}
