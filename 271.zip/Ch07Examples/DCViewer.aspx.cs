using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace Ch07Examples
{
	/// <summary>
	/// Summary description for DCViewer.
	/// </summary>
	public class DCViewer : System.Web.UI.Page
	{
        protected System.Web.UI.WebControls.Button bnGetStory;
        protected System.Web.UI.WebControls.Label lbAuthor;
        protected System.Web.UI.WebControls.Label lbStory;
        protected System.Web.UI.WebControls.DropDownList ddlStories;
    
		private void Page_Load(object sender, System.EventArgs e)
		{
            if (!IsPostBack)
            {
                string ConnectStr = 
                    "server=localhost;uid=sa;pwd=;database=DCV_DB";
                string Cmd = "SELECT StoryID, Headline FROM Content";
                
                SqlDataAdapter DAdpt = new SqlDataAdapter(Cmd, ConnectStr);

                DataSet ds = new DataSet();
                DAdpt.Fill(ds, "Content");

                DataTable dt = ds.Tables["Content"];

                foreach (DataRow dr in dt.Rows)
                {
                    ddlStories.Items.Add(
                        new ListItem(dr["Headline"].ToString(),
                        dr["StoryID"].ToString()));
                }
            }
        }

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
            this.bnGetStory.Click += new System.EventHandler(this.bnGetStory_Click);
            this.Load += new System.EventHandler(this.Page_Load);

        }
		#endregion

        private void bnGetStory_Click(object sender, System.EventArgs e)
        {
            if (Page.IsValid)
            {
                string ConnectStr = 
                    "server=localhost;uid=sa;pwd=;database=DCV_DB";
                string Cmd = "SELECT * FROM Stories WHERE StoryID = "
                    + ddlStories.SelectedItem.Value.ToString();
                
                SqlDataAdapter DAdpt = 
                    new SqlDataAdapter(Cmd, ConnectStr);

                DataSet ds = new DataSet();
                DAdpt.Fill (ds, "Stories");

                DataRow dr = ds.Tables["Stories"].Rows[0];

                lbAuthor.Text = "By " + dr["FirstName"] + " " + dr["LastName"];
                lbStory.Text = dr["Story"].ToString();
            }
        }

	}
}
