using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace Ch07Examples
{
	public class DCCMA : System.Web.UI.Page
	{
        protected System.Web.UI.WebControls.ValidationSummary ValSum;
        protected System.Web.UI.WebControls.DropDownList ddlAuthor;
        protected System.Web.UI.WebControls.TextBox tbHeadline;
        protected System.Web.UI.WebControls.RequiredFieldValidator rfvHeadline;
        protected System.Web.UI.WebControls.TextBox tbStory;
        protected System.Web.UI.WebControls.RequiredFieldValidator rfvStory;
        protected System.Web.UI.WebControls.Button bnSubmit;
        protected System.Web.UI.WebControls.Button bnClear;
        protected System.Web.UI.WebControls.Label lbError;
    
		private void Page_Load(object sender, System.EventArgs e)
		{
            if (!IsPostBack)
            {
                string ConnectStr = "server=localhost;uid=sa;pwd=;database=DCV_DB";
                string Cmd = 
                    "SELECT AuthorID, LastName, FirstName FROM Authors ORDER BY LastName";
                
                SqlDataAdapter DAdpt = new SqlDataAdapter(Cmd, ConnectStr);

                DataSet ds = new DataSet();
                DAdpt.Fill(ds, "Authors");

                DataTable dt = ds.Tables["Authors"];

                foreach (DataRow dr in dt.Rows)
                {
                    ddlAuthor.Items.Add(new ListItem(dr["LastName"] + ", " +
                        dr["FirstName"],
                        dr["AuthorID"].ToString()));
                }
            }
        }

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			InitializeComponent();
            base.OnInit(e);
		}
		
		private void InitializeComponent()
		{    
            this.bnSubmit.Click += new System.EventHandler(this.bnSubmit_Click);
            this.bnClear.Click += new System.EventHandler(this.bnClear_Click);
            this.Load += new System.EventHandler(this.Page_Load);

        }
        #endregion

        private void bnClear_Click(object sender, System.EventArgs e)
        {
            tbHeadline.Text = "";
            tbStory.Text = "";
        }

        private void bnSubmit_Click(object sender, System.EventArgs e)
        {
            if (Page.IsValid)
            {
                SqlConnection myConnection = new SqlConnection();
                myConnection.ConnectionString = "server=localhost;uid=sa;pwd=;database=DCV_DB";
                Content content = new Content(myConnection);

                try
                {
                    content.Insert(Convert.ToInt16(
                        ddlAuthor.SelectedItem.Value), 
                        tbHeadline.Text, 
                        tbStory.Text);

                    tbHeadline.Text = "";
                    tbStory.Text = "";
                }
                catch (SqlException err)
                {
                    lbError.Text = 
                        "Sorry, the following error occured: " + err.Message;
                }
            }
        }
	}
}
