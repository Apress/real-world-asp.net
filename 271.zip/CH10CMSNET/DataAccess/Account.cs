using System;
using System.Data;
using System.Data.SqlClient;
using System.Web.Security;

namespace CMSNET.DataAccess
{
    public class Account
    {
        private SqlConnection m_Connection;
        private SqlCommand    m_InsertCommand;
        private SqlCommand    m_UpdateCommand;

        public Account(SqlConnection Connection)
        {
            m_Connection = Connection;
        }

        public void Insert(string UserName, string Password, string Email)
        {
            // INSERT INTO Account (UserName, Password, Email, 
            //                      ModifiedDate, CreationDate) 
            // VALUES (@UserName, @Password, @Email, @ModifiedDate, @CreationDate)

            SqlParameterCollection Params;

            if ( m_InsertCommand == null )
            {
                m_InsertCommand = new SqlCommand("Account_Insert", m_Connection);
                m_InsertCommand.CommandType  = CommandType.StoredProcedure;
                Params = m_InsertCommand.Parameters;
            
                Params.Add(new SqlParameter("@UserName",     SqlDbType.Char, 32));
                Params.Add(new SqlParameter("@Password",     SqlDbType.Char, 40));
                Params.Add(new SqlParameter("@Email",        SqlDbType.Char, 64));
                Params.Add(new SqlParameter("@ModifiedDate", SqlDbType.DateTime));
                Params.Add(new SqlParameter("@CreationDate", SqlDbType.DateTime));
            }

            Params = m_InsertCommand.Parameters;

            Params["@UserName"].Value     = UserName;
            Params["@Password"].Value     = Password;
            Params["@Email"].Value        = Email;
            Params["@ModifiedDate"].Value = DateTime.Now;
            Params["@CreationDate"].Value = DateTime.Now;
					
            try
            {
                m_Connection.Open();
                m_InsertCommand.ExecuteNonQuery();
            }
            finally
            {
                m_Connection.Close();
            }
        }

        public void Update(int AccountID, string UserName, string Password, string Email)
        {
            //	UPDATE Account
            //     SET UserName     = @UserName,
            //         Password     = @Password,
            //         Email        = @Email,
            //         ModifiedDate = @ModifiedDate
            //  WHERE AccountID = @AccountID

            SqlParameterCollection Params;

            if ( m_UpdateCommand == null )
            {
                m_UpdateCommand = new SqlCommand("Account_Update", m_Connection);
                m_UpdateCommand.CommandType  = CommandType.StoredProcedure;
                Params = m_UpdateCommand.Parameters;
            
                Params.Add(new SqlParameter("@AccountID",    SqlDbType.Int));
                Params.Add(new SqlParameter("@UserName",     SqlDbType.Char, 32));
                Params.Add(new SqlParameter("@Password",     SqlDbType.Char, 40));
                Params.Add(new SqlParameter("@Email",        SqlDbType.Char, 64));
                Params.Add(new SqlParameter("@ModifiedDate", SqlDbType.DateTime));
            }

            Params = m_UpdateCommand.Parameters;

            Params["@AccountID"].Value    = AccountID;
            Params["@UserName"].Value     = UserName;
            Params["@Password"].Value     = Password;
            Params["@Email"].Value        = Email;
            Params["@ModifiedDate"].Value = DateTime.Now;
					
            try
            {
                m_Connection.Open();
                m_UpdateCommand.ExecuteNonQuery();
            }
            finally
            {
                m_Connection.Close();
            }
        }

        public bool Exist(int AccountID)
        {
            string Command = "Select * from Account WHERE AccountID="+AccountID;
            SqlDataAdapter DSCmd = new SqlDataAdapter(Command, m_Connection);

            DataSet ds = new DataSet();
            DSCmd.Fill(ds, "Account");

            return (ds.Tables["Account"].Rows.Count > 0);
        }
    }
}
