using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using CMSNET.Common;
using CMSNET.DataAccess;

namespace CMSNET.Administration.AUT
{
	/// <summary>
	/// Summary description for AutUpdate.
	/// </summary>
	public class AutUpdate : CMSNET.Common.AuthorizedPage
	{
        protected System.Web.UI.WebControls.ValidationSummary ValSum;
        protected System.Web.UI.WebControls.Label lbContentID;
        protected System.Web.UI.WebControls.Label lbVersion;
        protected System.Web.UI.WebControls.TextBox tbHeadline;
        protected System.Web.UI.WebControls.RequiredFieldValidator rfvHeadline;
        protected System.Web.UI.WebControls.Label lbByline;
        protected System.Web.UI.WebControls.TextBox tbTeaser;
        protected System.Web.UI.WebControls.TextBox tbBody;
        protected System.Web.UI.WebControls.RequiredFieldValidator rfvBody;
        protected System.Web.UI.WebControls.TextBox tbTagline;
        protected System.Web.UI.WebControls.Label lbModifiedDate;
        protected System.Web.UI.WebControls.Label lbCreationDate;
        protected System.Web.UI.WebControls.Button bnInsert;
        protected System.Web.UI.WebControls.Button bnUpdate;
        protected System.Web.UI.WebControls.Button bnRestore;
        protected System.Web.UI.WebControls.Button bnRemove;
    
        protected DataTable dt;
        
        private void BuildOrigPage()
        {
            DataRow dr = dt.Rows[0];

            lbContentID.Text = dr["ContentID"].ToString();
            lbVersion.Text   = dr["Version"].ToString();
            tbHeadline.Text  = dr["Headline"].ToString();
            lbByline.Text    = dr["Byline"].ToString();
            tbTeaser.Text    = dr["Teaser"].ToString();
            tbBody.Text      = dr["Body"].ToString();
            tbTagline.Text   = dr["Tagline"].ToString();
            lbModifiedDate.Text  = dr["ModifiedDate"].ToString();
            lbCreationDate.Text  = dr["CreationDate"].ToString();
        }

        private void Page_Load(object sender, System.EventArgs e)
		{
            int cid = Convert.ToInt32(Request.QueryString["ContentID"]);

            if (cid == 0)
            {
                Page_Error("ContentID Missing");
            }
            dt = new Content(appEnv.GetConnection()).GetContentForID(cid);

            if (!IsPostBack)
            {
                BuildOrigPage();
            }
        }

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
            this.bnInsert.Click += new System.EventHandler(this.bnInsert_Click);
            this.bnUpdate.Click += new System.EventHandler(this.bnUpdate_Click);
            this.bnRestore.Click += new System.EventHandler(this.bnRestore_Click);
            this.bnRemove.Click += new System.EventHandler(this.bnRemove_Click);
            this.Load += new System.EventHandler(this.Page_Load);

        }
		#endregion

        private void bnInsert_Click(object sender, System.EventArgs e)
        {
            if (Page.IsValid)
            {
                try
                {
                    Content content = new Content(appEnv.GetConnection());
                    Account account = new Account(appEnv.GetConnection());
                    content.Insert(Convert.ToInt32(lbContentID.Text),
                        Convert.ToInt32(lbVersion.Text) + 1,
                        tbHeadline.Text, Convert.ToInt32(lbByline.Text), tbTeaser.Text, tbBody.Text, tbTagline.Text, account.GetAccountID(User.Identity.Name));
                }
                catch (Exception err)
                {
                    Page_Error("The following error occured: " + err.Message);
                }

                Response.Redirect("AutList.aspx");
            }
        }

        private void bnUpdate_Click(object sender, System.EventArgs e)
        {
            if (Page.IsValid)
            {
                try
                {
                    Content content = new Content(appEnv.GetConnection());
                    Account account = new Account(appEnv.GetConnection());
                    content.Update(Convert.ToInt32(lbContentID.Text),
                        Convert.ToInt32(lbVersion.Text),
                        tbHeadline.Text, Convert.ToInt32(lbByline.Text), tbTeaser.Text, tbBody.Text, tbTagline.Text, account.GetAccountID(User.Identity.Name));
                }
                catch (Exception err)
                {
                    Page_Error("The following error occured: " + err.Message);
                }

                Response.Redirect("AutList.aspx");
            }
        }

        private void bnRestore_Click(object sender, System.EventArgs e)
        {
            BuildOrigPage();
        }

        private void bnRemove_Click(object sender, System.EventArgs e)
        {
            Response.Redirect("AutRemove.aspx?ContentID=" + lbContentID.Text);
        }
	}
}
