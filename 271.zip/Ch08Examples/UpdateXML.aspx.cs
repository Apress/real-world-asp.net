using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Xml;

namespace Ch08Examples
{
	public class UpdateXML : System.Web.UI.Page
	{
        protected System.Web.UI.WebControls.ListBox lbBefore;
        protected System.Web.UI.WebControls.ListBox lbAfter;
    
		private void Page_Load(object sender, System.EventArgs e)
		{
            if (!IsPostBack)
            {
                XmlReader reader = new XmlTextReader(
                    File.OpenRead(Server.MapPath("XMLFiles\\Authors.xml")));

                XmlDocument doc = new XmlDocument();
                doc.Load(reader);
                reader.Close();

                // Displaying XML Document before insert & update
                XmlNodeList fnames = doc.GetElementsByTagName("FirstName");
                XmlNodeList lnames = doc.GetElementsByTagName("LastName");

                for (int i = 0; i < lnames.Count; i++)
                {
                    lbBefore.Items.Add(fnames[i].InnerText + " " + 
                        lnames[i].InnerText);
                }

                // Inserting

                XmlDocumentFragment newAuthor = doc.CreateDocumentFragment();
                newAuthor.InnerXml=("\n  <Author>\n" +
                    "    <FirstName>John</FirstName>\n" +
                    "    <LastName>Doe</LastName>\n" +
                    "  </Author>\n");

                //insert the new author after 2nd author
                XmlElement  root  = doc.DocumentElement;
                XmlNodeList nodes = root.GetElementsByTagName("Author");
                root.InsertAfter(newAuthor,nodes.Item(1));

                // Updating

                // Get New node list with inserted author
                nodes = root.GetElementsByTagName("Author");

                for (int i=0; i < nodes.Count; i++)
                {
                    XmlNodeList authornodes = 
                        ((XmlElement)(nodes.Item(i))).
                        GetElementsByTagName("LastName");

                    for (int j=0; j < authornodes.Count; j++)
                    {
                        if (authornodes[j].InnerText.Equals("Fraser"))
                        {
                            authornodes[j].InnerText = "The Author";
                        }
                    }
                }

                // Normally you would save the document but we want to
                // be able to re-run this

                // StreamWriter writer = new StreamWriter(
                // File.OpenWrite(Server.MapPath("XMLFiles\\Authors.xml")));
                // doc.Save(writer);
                // writer.Close();

                // Reading XML Document after insert & update

                fnames = doc.GetElementsByTagName("FirstName");
                lnames = doc.GetElementsByTagName("LastName");

                for (int i = 0; i < lnames.Count; i++)
                {
                    lbAfter.Items.Add(fnames[i].InnerText + " " + 
                        lnames[i].InnerText);
                }
            }
        }

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			InitializeComponent();
			base.OnInit(e);
		}
		
		private void InitializeComponent()
		{    
            this.Load += new System.EventHandler(this.Page_Load);

        }
		#endregion
	}
}
