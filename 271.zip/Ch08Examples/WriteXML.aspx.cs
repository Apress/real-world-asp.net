using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Xml;
using System.Xml.XPath;

namespace Ch08Examples
{
	public class WriteXML : System.Web.UI.Page
	{
        protected System.Web.UI.WebControls.ListBox lbXPath;
    
        private void DisplayXMLTree (XPathNavigator nav)
        {
            if (nav.HasChildren)
            {
                nav.MoveToFirstChild();
                FormatXML (nav);
                DisplayXMLTree (nav); 
                nav.MoveToParent();
                lbXPath.Items.Add("</" + nav.Name + ">");
            }
            while (nav.MoveToNext())
            {
                FormatXML (nav);
                DisplayXMLTree (nav); 
            }
        }

        private void FormatXML (XPathNavigator nav)
        {
            if (!nav.HasChildren)
            {
                lbXPath.Items.Add("->" + nav.Value);
            }
            else
            {
                lbXPath.Items.Add("<" + nav.Name + ">");
            }
        }

        private void Page_Load(object sender, System.EventArgs e)
		{
            if (!IsPostBack)
            {
                XmlTextWriter writer = new XmlTextWriter(
                    Server.MapPath("XMLFiles/MyContent.xml"),
                    null);

                // set up indenting format
                writer.Formatting = Formatting.Indented;
                writer.Indentation = 2;

                // start XML document
                writer.WriteStartDocument();

                // Write XML document
                writer.WriteStartElement("", "Content", "");
                writer.WriteStartElement("", "ContentForAuthor", "");
                writer.WriteStartElement("", "Author", "");
                writer.WriteStartElement("", "FirstName", "");
                writer.WriteString("John");
                writer.WriteEndElement();
                writer.WriteStartElement("", "LastName", "");
                writer.WriteString("Doe");
                writer.WriteEndElement();
                writer.WriteEndElement();
                writer.WriteStartElement("", "Articles", "");
                writer.WriteStartElement("", "Headline", "");
                writer.WriteString("This is the Headline");
                writer.WriteEndElement();
                writer.WriteStartElement("", "Story", "");
                writer.WriteString("The story is entered here.");

                // not needed as XmlTextWrite closes all open elements
                // with WriteEndDocument

                // writer.WriteEndElement();
                // writer.WriteEndElement();
                // writer.WriteEndElement();
                // writer.WriteEndElement();

                // End XML document
                writer.WriteEndDocument();

                // Close document so that it can be opened again 
                // form the XPathNavigator process of document
                writer.Close();

                // Read created file using XPathNavigator
                XPathDocument doc = new XPathDocument(
                    new XmlTextReader(
                    "http://localhost/Ch08Examples/XMLFiles/MyContent.xml"));

                XPathNavigator nav = doc.CreateNavigator();

                nav.MoveToRoot();

                // Recursive navigation of the DOM tree
                DisplayXMLTree(nav); 
            }
        }

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			InitializeComponent();
			base.OnInit(e);
		}
		
		private void InitializeComponent()
		{    
            this.Load += new System.EventHandler(this.Page_Load);

        }
		#endregion
	}
}
