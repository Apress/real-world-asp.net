using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Xml;

namespace Ch08Examples
{
	public class ReadXML : System.Web.UI.Page
	{
        protected System.Web.UI.WebControls.ListBox lbReadXML;
    
		private void Page_Load(object sender, System.EventArgs e)
		{
            if (!IsPostBack)
            {
                // Read using XmlReader

                XmlTextReader reader = new XmlTextReader(
                    "http://localhost/Ch08Examples/XMLFiles/Content.xml");

                while (reader.Read())
                {
                    if (reader.NodeType == XmlNodeType.Element)
                    {
                        lbReadXML.Items.Add("<" + reader.LocalName + ">");
                    }
                    else if (reader.NodeType == XmlNodeType.Text)
                    {
                        lbReadXML.Items.Add("->" + reader.Value);
                    }
                    else if (reader.NodeType == XmlNodeType.EndElement)
                    {
                        lbReadXML.Items.Add("</" + reader.LocalName + ">");
                    }
                }
            }
        }

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			InitializeComponent();
			base.OnInit(e);
		}
		
		private void InitializeComponent()
		{    
            this.Load += new System.EventHandler(this.Page_Load);

        }
		#endregion
	}
}
